package iiitd.nrl.evalapp;

public class MainLauncher {
    public static void main(String[] args) {
        Main.main(args);
    }
}
